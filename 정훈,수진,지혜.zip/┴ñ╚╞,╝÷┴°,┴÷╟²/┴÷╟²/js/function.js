
// 스크롤이 (헤더높이90+섹션마진탑50+메인아티클마진탑10)=150 에 도달했을 때 

// section > div#main > article#selectCategory
// section > div#main > article#bestPost
// pos:fixed;
const $category = document.getElementById('selectCategory');
const $bestPost = document.getElementById('bestPost');

window.addEventListener('scroll', ()=>{
  const scrollTop = Math.ceil(window.scrollY);
  // const scrollHeight = document.documentElement.scrollHeight;
  // const clientHeight = document.documentElement.clientHeight;

  if(scrollTop >= 50) {
    $category.style.top = (scrollTop-50) + 'px';
  } else if(scrollTop < 50) {
    $category.style.top = 'initial';
  }

  // if(scrollTop + clientHeight >= scrollHeight) {
    // $category.style.top = 'initial';
  // }

  if(scrollTop >= 95) {
    $bestPost.style.top = (scrollTop-95) + 'px';
  } else if(scrollTop < 95 || window.innerHeight + scrollTop >= document.body.offsetHeight) {
    $bestPost.style.top = '0';
  }

});

